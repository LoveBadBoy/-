//
//  ShopsController.h
//  PaoFan
//
//  Created by 王忠良 on 16/8/22.
//  Copyright © 2016年 王忠良. All rights reserved.
//

#import "PFBaseViewController.h"

@interface ShopsController : PFBaseViewController

@end
